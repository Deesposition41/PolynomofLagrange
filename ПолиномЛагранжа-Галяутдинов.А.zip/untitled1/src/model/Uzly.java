package model;

public class Uzly {
    public double x[];
    public double y[];


    public Uzly(int n,double[] x,double [] y) {

        this.x = x;
        this.y = y;
    }


}
